<?php
# 資料庫設定
$hostname = 'localhost';
$database = 'school';
$dbuser = 'root';
$dbpass = '';
# 首頁設定
$main = 'movie_list.php';
?>